# Tình trạng submission — Nguyễn Hồ Bắc · 2A202603351 · G05

## Đã chuẩn bị

- E1: export_final.zip giữ nguyên của người học, 22 ảnh, ZIP chỉ có annotations.xml.
- E2: check_cpA.txt giữ nguyên bằng chứng cũ (8 ảnh, 2 lỗi thiếu tag); check_cpB.txt chạy bổ sung từ final trên D01–D02, không phải checkpoint lịch sử; check_final.txt kiểm lại đủ 22 ảnh, 0 lỗi và 0 cảnh báo.
- E3: disagreement_log.csv có 4 dòng diff, đã điền cả 4 theo guideline. Giữ bản mình; chưa có thay đổi nhãn nên không tạo v2.
- E4: ir_log.csv có 4 dòng từ bằng chứng XML, tách IR-sim và IR thật. **Chưa đủ quan sát thị giác được người học xác nhận.**
- E5: class_list_v0.md có 8 mục DMS, 8 mục OMS và 2 câu hỏi kèm tên khung.
- Có TEAM.md (peer Đào Bình An), self_review.md, prompts.md và exit_ticket.md.

## Cần người học hoàn tất trước khi nộp

1. Trên CVAT, xử lý 9 object ở D01–D06 theo GUIDE §4.2; chưa sửa XML hay tạo export v2. Nếu sửa, export CVAT 1.1 không kèm ảnh và chạy lại check theo CHECKPOINTS.md. Nếu đã nộp quá hạn thì theo RULES §6, chỉ ghi lỗi vào self_review thay vì đổi export đã nộp.
2. Xác nhận trên ảnh lý do không có face ở D01/D04, unknown/other ở D03 và các quan sát thực tế cho 4 dòng ir_log.csv. Không đưa ảnh cho AI.
3. Tự điền exit_ticket.md; xác nhận tự đánh giá phản ánh trải nghiệm của mình. Không có bằng chứng peer đúng và mình sai trong diff này.
4. Nếu nộp GitHub, kiểm yêu cầu ít nhất 2 commit cá nhân; phiên này chưa tạo commit hoặc push.

## Gói nộp

Thư mục `K5-L2-DAY12-NguyenHoBac-2A202603351-DMSOMS/` và file ZIP cùng tên được chuẩn bị từ danh sách file cho phép. Không kèm ảnh, manifest, thư mục G05, bản peer hay source của repo. ZIP hiện là **bản chuẩn bị**, cần hoàn tất các mục trên trước khi nộp LMS. Sau khi sửa tài liệu hoặc export, cần cập nhật lại gói ZIP.
